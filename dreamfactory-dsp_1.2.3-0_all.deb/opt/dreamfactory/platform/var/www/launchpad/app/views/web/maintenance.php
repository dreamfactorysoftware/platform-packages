<?php
/**
 * Maintenance Mode Page
 */
?>
<div class="container maintenance">
	<div class="jumbotron">
		<h1>Dagnabit!</h1>

		<p>We promise, it will be back online soon. Most likely we are upgrading to the latest release which could be something really cool! You just never know...</p>

		<p>kthxbai!</p>
	</div>
</div>