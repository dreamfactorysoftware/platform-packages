# dsp-core

## DreamFactory Services Platform(tm) Core v1.2.x

Complete documentation is available on our [dedicated site](http://dreamfactorysoftware.github.io/)

## Feedback and Contributions

* Feedback is welcome in the form of pull requests and/or issues.
* Contributions should generally follow the strategy outlined in ["Contributing
  to a project"](https://help.github.com/articles/fork-a-repo#contributing-to-a-project)
* All pull requests must be in a ["git flow"](https://github.com/nvie/gitflow) feature branch to be considered.
