DF = {};
DF.Application = function (config) {
    this.config = config;
    this.actions = Actions;
    this.currentState = "";
    this.currentData = "";
    this.templates = Templates;
    this.utils = {

    };
};



