# dsp-core

### DreamFactory Services Platform(tm) v1.0.6

Please see our [site](http://dreamfactorysoftware.github.io) for full documentation.
